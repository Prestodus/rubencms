<?php

class getsetController extends Base_Controller {

	public function indexAction() {

		$this->view->title = 'index title';

		return $this;

	}

	public function newAction() {

		$this->view->title = 'new title';

		return $this;

	}

	public function editAction() {

		$this->view->title = 'edit title';

		return $this;

	}

	public function deleteAction() {

		$this->view->title = 'delete title';

		return $this;

	}

	public function randomAction() {

		$this->view->title = 'random title';

		return $this;

	}

}